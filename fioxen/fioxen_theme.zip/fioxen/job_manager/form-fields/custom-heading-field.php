<?php
if ( ! defined( 'ABSPATH' ) ) {
   exit; // Exit if accessed directly.
}
?>

<?php if($field['label']){ ?>
   <div class="heading-text"><?php echo esc_html($field['label']) ?></div>
<?php } ?>   
